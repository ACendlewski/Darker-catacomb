public static class AnimationConstants
{
    public const string Attack = "attack";
    public const string Die = "die";
    public const string Hurt = "hurt";
    public const string Idle = "idle";
    public const string Victory = "victory";
}
